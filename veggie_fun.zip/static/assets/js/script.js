document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('multi-step-form');
    const fieldsets = form.querySelectorAll('fieldset');
    let currentStep = 0;

    function showStep(step) {
        fieldsets.forEach((fieldset, index) => {
            if (index === step) {
                fieldset.style.display = 'block';
            } else {
                fieldset.style.display = 'none';
            }
        });
    }

    function prevStep() {
        if (currentStep > 0) {
            currentStep--;
            showStep(currentStep);
        }
    }

    function nextStep() {
        if (currentStep < fieldsets.length - 1) {
            currentStep++;
            showStep(currentStep);
        }
    }

    form.addEventListener('submit', function () {
        // event.preventDefault();
        // Here you can add your form submission logic
        // For demonstration purposes, we're just logging the form data
        const formData = new FormData(form);
        for (let pair of formData.entries()) {
            console.log(pair[0] + ': ' + pair[1]);
        }
    });

    const prevButtons = document.querySelectorAll('.prev');
    prevButtons.forEach(button => {
        button.addEventListener('click', prevStep);
    });

    const nextButtons = document.querySelectorAll('.next');
    nextButtons.forEach(button => {
        button.addEventListener('click', nextStep);
    });
});

