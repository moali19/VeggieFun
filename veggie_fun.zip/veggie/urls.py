from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views 
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',views.home,name='racipe_page'),
    path('game',views.home,name='main_home'),
    path('welcome',views.welcome,name='welcome'),
    path('myform',views.myform,name='myform'),
    path('racipe_page',views.racipe_page,name='racipe_page'),
    path("test", views.test, name="game2"),
    path('all_recipes',views.all_recipes,name='all_recipes'),
    path('contact',views.contact,name='contact'),
    path('contact_action',views.contact_action,name='contact_action'),
    path("about", views.about, name="about"),
    path('detail/<int:id>',views.detail,name='detail'),
    path('test_ans',views.test_ans,name='test_ans'),
    path('username',views.username,name='username'),
    path('assistant',views.assistant,name='assistant'),
    path('assisting',views.assisting,name='assisting'),
    path('Profile_Edit',views.Profile_Edit,name="Profile_Edit"),
    path('Profile',views.Profile_page,name="Profile_page"),
    path("game_page", views.game_page, name="game_page"),
    path("game_02_result",views.game_02_result, name="game_02_result"),
    path("select_image", views.select_image, name="select_image"),
    path("game_03_result",views.game_03_result, name="game_03_result"),
# assistant






    path("accounts/login/",views.index,name="login_main_view"),
    path("login_view",views.index,name="login"),
    path("logout_view",views.logout_view,name="logout_view"),
    path("login",views.login_view,name="home"),
    path("sign",views.regester,name="signhome"),
    path("regester",views.sign_in,name="regesterhome"),
    path('password_reset/',auth_views.PasswordResetView.as_view(template_name="password_reset_form.html"),name='password_reset'),
    path('password_reset_sent/',auth_views.PasswordResetDoneView.as_view(template_name = "password_reset_done.html"),name='password_reset_done'),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name = "password_reset_confirm.html"),name='password_reset_confirm'),
    path('reset_password_complete/',auth_views.PasswordResetCompleteView.as_view(template_name = "password_reset_complete.html"),name='password_reset_complete'),
    ] +  static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
 