from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.views import PasswordResetView
from .models import *
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import JsonResponse
import random

def index(request):
    context = {'page': 'home'}
    return render(request,'login.html',context)
def regester(request):
    return render(request,'sign_up.html')
# Create your views here.
def sign_in(request):
        if request.method == 'POST':
            email = request.POST.get('email')
            password = request.POST.get('password')
            password2 = request.POST.get('password2')
            if password == password2:
                print("equal")
                user = User.objects.create_user(username=email, password=password)
                user.save()
                login(request, user)
                result = Result(user = request.user)
                result.save()
                
                return redirect("/racipe_page")
            else:
                messages.error(request, 'This is a error message.')
                return redirect('/sign')
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            
            return redirect("/racipe_page") 
        else:
            messages.error(request, 'Incorrect Username or Password')
            return redirect("/login_view")
def logout_view(request):
    logout(request)
    return redirect('/login_view')
def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}. You can now login.')
            return redirect('login')  # Redirect to login page after successful registration
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})  # Render sign up form template

def home(request):
    context ={
        'page': 'game'
    }
    return render(request,'index.html',context)
@login_required
def welcome(request):
    return render(request,'welcome.html')
@login_required
def myform(request):
    test= Game_1.objects.all()
    random_object = random.choice(test)
    const = {
        'text':test,
        'random_object': random_object
    }
    return render(request,'myform.html',const)
@login_required
def racipe_page(request):
    recipe = Recipe.objects.all() 
    page = "home"
    const = {
        'recipe':recipe, 
        'page': page
    }
    return render(request,'racipe_page.html',const)
@login_required
def all_recipes(request):
    breakfast = Recipe.objects.filter(category='Breakfast')
    dinner = Recipe.objects.filter(category='Dinner')
    snacks = Recipe.objects.filter(category='Snacks')
    desserts = Recipe.objects.filter(category='Desserts') 
    const = {
        'breakfast': breakfast,
        'dinner': dinner,
        'snacks': snacks,
        'desserts': desserts, 
        'page': 'recipes'

    }
    return render(request,'all_recipes.html',const) 
@login_required
def contact(request): 
    context = {
        'page':'contact'
    }
    return render(request,'contact.html',context )
@login_required
def contact_action(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        message = request.POST['message']
        contact = Contact(name=name,email=email,message=message)
        contact.save()
        messages.success(request, 'We Contact you as well as soon')
        return redirect('/contact')
def detail(request,id):
    recipe = Recipe.objects.get(pk = id) 
    const = {
        'recipe':recipe, 
    }
    return render(request,'recipe_detail.html',const)

def test_ans(request):
    if request.method == "GET":
        id = request.GET['random_id']
        name = request.GET['name']
        fil = Game_1.objects.get(pk = id)
        if fil.veggie_name.lower() == name.lower():
            correct_result = Result.objects.filter(user = request.user).first()
            level = ''
            if correct_result:
                correct_result.level += 1
                correct_result.save()
                level = correct_result.level

            else:
                result = Result(user = request.user)
                result.level += 1
                result.save()
                level = correct_result.level
            ussser = usercreate.objects.filter(saveduser = request.user).order_by('-id').first()
            return render(request,'result.html',{'ussser':ussser,'level':level})
        else:
            ussser = usercreate.objects.filter(saveduser = request.user).order_by('-id').first()
            correct_result = Result.objects.filter(user = request.user).first()
            if not correct_result:
                result = Result(user = request.user)
                print('exists')
                result.save()
            return render(request,'fail.html',{'ussser':ussser})
        return HttpResponse(f'{id},{name},{fil}')
def username(request):
    if request.method == 'GET':
        name = request.GET['name']
        useeer = usercreate(name=name,saveduser=request.user)
        useeer.save()
        return redirect('/myform')
def assistant(request):
    try:
        result = Result.objects.get(user=request.user)
    except Result.DoesNotExist:
        result = None
    return render(request,'assisting.html',{'result':result})
def assisting(request):
    if request.method == 'GET':
        checkbox = request.GET['option']
        asses = Assistant(user = request.user, name=checkbox)
        asses.save()
        return redirect('/')
    
def Profile_Edit(request):
    profile_already = Profile.objects.filter(user = request.user).first()
    mainrequest = request.POST
    if profile_already:
        if request.method == "POST":
            profile_already.Image = request.FILES.get('picture__input')
            profile_already.First_Name = mainrequest['fname']
            profile_already.Last_Name = mainrequest['lname']
            profile_already.age= mainrequest['age']
            profile_already.nickname= mainrequest['email']
            profile_already.Favourite_Veggie = mainrequest['phonenumber']
            profile_already.hobby = mainrequest['hobby']
            profile_already.Education = mainrequest['education']

            profile_already.save()
            # profile = Profile(Image = picture__input, First_Name = fname, Last_Name = lname, Phone_Number = phone_number, Email_Address = email, hobby = hobby, age = age , Education = education,user = request.user )
            return redirect("/Profile")
    else:
        if request.method == "POST":
            
            print(request.FILES,'___________________________________________________')
            picture__input = request.FILES.get('picture__input')
            print(picture__input)
            fname = mainrequest['fname']
            lname = mainrequest['lname']
            age= mainrequest['age']
            email= mainrequest['email']
            phone_number = mainrequest['phonenumber']
            hobby = mainrequest['hobby']
            education = mainrequest['education']
            profile = Profile(Image = picture__input, First_Name = fname, Last_Name = lname, Favourite_Veggie = phone_number, nickname = email, hobby = hobby, age = age , Education = education,user = request.user )
            profile.save()
            return redirect("/Profile")
 
    return render(request,'profile_edit.html',{ 'profile_already':profile_already})
def Profile_page(request):
    profile = Profile.objects.filter(user = request.user).first()
    if profile: 
        return render(request,'profile.html',{'profile':profile})
    else:
        return redirect('/Profile_Edit')

@login_required
def test(request):
    question = Game_2.objects.all() 
    print(len(question))
    const = {
        'questions':question
    }
    return render(request,"start_quiz.html",const)
def game_02_result(request):
        if request.method == "POST":
            total_question = Game_2.objects.all().count()
            correct_answers = 0
            wrong_answers = 0
            correct_result = Result.objects.filter(user = request.user).first()
            level = 0
            for question_id, answer_text in request.POST.items():
                if question_id.startswith('answer'):
                    print(question_id,answer_text,"___________________________________")
                    question_id = question_id.replace('answer', '')  # Extract question ID from the field name
                    question_id = int(question_id)  # Convert to integer
                    question_modal = Game_2.objects.get(id=question_id)
                    print(question_modal,answer_text)
                    if question_modal.CorrectAnswer == answer_text:
                        correct_answers += 1
                    else:
                        wrong_answers += 1
            if total_question == correct_answers:
                print("equal") 
                if correct_result:
                    level = correct_result.level
                    correct_result.level += 1
                    correct_result.save() 
                    level += 1
                else:
                    result = Result(user = request.user)
                    result.level += 1
                    result.save() 
                    level += 1

            context = {
                'total_question':total_question,
                'correct_answers':correct_answers,
                'wrong_answers':wrong_answers,
                'level':level
            }
            return render(request,'result2.html',context)
def game_page(request):
    context = {
        'page': 'game' 
    }
    return render(request,'game_page.html',context)
def select_image(request):
    game_image = Game_3.objects.all()
    const = {
        'questions':game_image
    }
    return render(request,'select_image.html',const)

def game_03_result(request):
        if request.method == "POST":
            total_question = Game_3.objects.all().count()
            correct_answers = 0
            wrong_answers = 0
            correct_result = Result.objects.filter(user = request.user).first() 
            level = 0
            for question_id, answer_text in request.POST.items():
                if question_id.startswith('answer'):
                    print(question_id,answer_text,"___________________________________")
                    question_id = question_id.replace('answer', '')  # Extract question ID from the field name
                    question_id = int(question_id)  # Convert to integer
                    answer_text_image = answer_text.replace('/media/','')
                    question_modal = Game_3.objects.get(id=question_id)
                    print(question_modal.CorrectAnswer,answer_text,answer_text_image) 
                    if question_modal.CorrectAnswer == answer_text:
                        correct_answers += 1
                    else:
                        wrong_answers += 1
            if total_question == correct_answers:
                print("equal")
                
                if correct_result:
                    level = correct_result.level
                    correct_result.level += 1
                    correct_result.save() 
                    level += 1
                else:
                    result = Result(user = request.user)
                    result.level += 1
                    result.save() 
                    level += 1

            context = {
                'total_question':total_question,
                'correct_answers':correct_answers,
                'wrong_answers':wrong_answers,
                'level':level
            }
            return render(request,'result2.html',context)
def about(request):
    context = {
        'page': 'about'
    }
    return render(request,'about.html',context)