from django.db import models
from ckeditor.fields import RichTextField
from django.contrib.auth.models import User

# Create your models here.
class Game_1(models.Model):
    veggie_image = models.ImageField(upload_to='images/')
    veggie_name = models.CharField(max_length=1000)
    def __str__(self) -> str:
        return self.veggie_name

# Create your models here.
class Contact(models.Model):
    name = models.CharField(max_length=1000)
    email = models.CharField(max_length=1000)
    message = models.TextField()
    def __str__(self) -> str:
        return self.name
class Category(models.Model):
    recipe_type = models.CharField(max_length=1000)

    def __str__(self):
        return self.recipe_type
class Recipe(models.Model):
    CHOICES = (
        ('Breakfast', 'Breakfast'),
        ('Dinner', 'Dinner'),
        ('Snacks', 'Snacks'),
        ('Desserts', 'Desserts'),
    )
    veggie_image = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=1000)
    calories = models.CharField(max_length=1000)
    total_Fat = models.CharField(max_length=1000)
    protein = models.CharField(max_length=1000)
    carbohydrate = models.CharField(max_length=1000)
    cholesterol = models.CharField(max_length=1000)
    time = models.CharField(max_length=1000)
    category = models.CharField(max_length=1000, choices=CHOICES)
    message = RichTextField()
    def __str__(self) -> str:
        return self.name
class usercreate(models.Model):
    name = models.CharField(max_length=1000)
    saveduser = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self) -> str:
        return self.name
 
class Result(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    level = models.IntegerField(default=0) 
    def __str__(self) -> str:
        return self.user.email
    
class Profile(models.Model):
    Image = models.ImageField(upload_to='images/')
    First_Name =  models.CharField(max_length=1000)
    Last_Name = models.CharField(max_length=1000)
    nickname = models.CharField(max_length=1000)
    Favourite_Veggie = models.CharField(max_length=1000)
    Education = models.CharField(max_length=1000)
    hobby = models.TextField()
    age = models.IntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self) -> str:
        return self.First_Name
    
class Game_2(models.Model):
    question = models.TextField()
    Option_1 = models.CharField(max_length=100)
    Option_2 = models.CharField(max_length=100)
    Option_3 = models.CharField(max_length=100)
    Option_4 = models.CharField(max_length=100)
    CorrectAnswer = models.CharField(max_length=100)
    def __str__(self):
        return self.question
    
class Solution(models.Model):
    question = models.ForeignKey(Game_2, on_delete=models.CASCADE)
    answer = models.TextField()
    studentName = models.ForeignKey(User, on_delete=models.CASCADE)
    is_correct = models.BooleanField(default=False) 
    def __str__(self):
        return self.question.question  
 
class Game_3(models.Model):
    CHOICES= (
        ('Option_1','Option_1'),
        ('Option_2','Option_2')
    )
    question = models.TextField()
    Option_1 = models.ImageField(upload_to='images/')
    Option_2 = models.ImageField(upload_to='images/')
    CorrectAnswer =  models.CharField(max_length=100,choices=CHOICES,null=True,blank=True)
    def __str__(self):
        return self.question