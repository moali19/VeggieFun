from django.contrib import admin
from .models import *
# admin.site.register(Assistant)
admin.site.register(Profile)
admin.site.register(usercreate)
admin.site.register(Recipe)
admin.site.register(Game_1)
admin.site.register(Contact)
admin.site.register(Result)
admin.site.register(Game_2)
# admin.site.register(Result_Game2)
admin.site.register(Game_3)
